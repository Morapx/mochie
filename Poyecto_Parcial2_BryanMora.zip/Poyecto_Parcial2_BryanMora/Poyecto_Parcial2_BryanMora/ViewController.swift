//
//  ViewController.swift
//  Poyecto_Parcial2_BryanMora
//
//  Created by Alumno on 10/13/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ListaEnciclopediaMarinaController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return EnciclopediaMarina.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaRegionMarina") as! CeldaEnciclopediaController
        celda.lblNombre.text = EnciclopediaMarina[indexPath.row].nombre
    
        
        return celda
    }
    

    var EnciclopediaMarina : [Regionmarina] = []
    
   
    @IBOutlet weak var tvRegiones: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Inciclopedia Marina"
        
        EnciclopediaMarina.append(Regionmarina(nombre: "Mar", familiaanimal: "Familia de agia salada", peso: "3kg hasta 150.000kg", fauna: "Desde inofensivos coloridos hasta gigantes pasivos", flora: "De calida y verde a colorida y resistente"))
        
        EnciclopediaMarina.append(Regionmarina(nombre: "Lagos, rios y lagunas", familiaanimal: "Familia de agua dulce", peso: "0.500gr hasta 1100kg", fauna: "De ramas pequeñas debajo del agua hasta plantas que flotan por encima del agua", flora: "Flora verdosa, amplia y frajil como resistente"))
        
        EnciclopediaMarina.append(Regionmarina(nombre: "Pantano", familiaanimal: "Familia pantanosa", peso: "0.200gr hasta 1000kg", fauna: "Desde pequeños inofensivos, hasta reptiles carnivoros" , flora: "Flora Marchital"))
    }
    //impresionanti
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destino = segue.destination as! DetallesRegion
        destino.regionmarina = EnciclopediaMarina[tvRegiones.indexPathForSelectedRow!.row]
    }


}

