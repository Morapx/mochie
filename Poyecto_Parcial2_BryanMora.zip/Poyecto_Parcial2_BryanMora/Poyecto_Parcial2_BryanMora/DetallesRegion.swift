//
//  DetallesRegion.swift
//  Poyecto_Parcial2_BryanMora
//
//  Created by Alumno on 10/22/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class DetallesRegion : UIViewController {
    
    var regionmarina : Regionmarina =  Regionmarina(nombre: "", familiaanimal: "", peso: "", fauna: "", flora: "")
    
    override func viewDidLoad() {
        self.title = regionmarina.nombre
    }
    
}
