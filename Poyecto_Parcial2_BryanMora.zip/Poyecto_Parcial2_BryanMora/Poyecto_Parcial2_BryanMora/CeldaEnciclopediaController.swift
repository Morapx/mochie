//
//  CeldaEnciclopediaController.swift
//  Poyecto_Parcial2_BryanMora
//
//  Created by Alumno on 10/21/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class CeldaEnciclopediaController : UITableViewCell {
    
    
    @IBOutlet weak var lblNombre: UILabel!
}
