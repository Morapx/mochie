//
//  Regionmarina.swift
//  Poyecto_Parcial2_BryanMora
//
//  Created by Alumno on 10/13/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Regionmarina {
    var nombre = ""
    var familiaanimal = ""
    var peso = ""
    var fauna = ""
    var flora = ""

    
    init(nombre: String, familiaanimal: String, peso: String, fauna: String, flora: String) {
        self.nombre = nombre
        self.familiaanimal = familiaanimal
        self.peso = peso
        self.fauna = fauna
        self.flora = flora

    }
}
